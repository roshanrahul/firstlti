package com.lnt.mvc.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.lnt.mvc.model.Department;
import com.lnt.mvc.model.EmployeeDetails;
import com.lnt.mvc.model.Person;

@Repository
public class DepartmentDAOImpl implements IDepartmentDAO{

	
	private static final Logger logger = 			
			LoggerFactory.getLogger(PersonDaoImpl.class);

	private SessionFactory sessionFactory;

	
	
	@Override
	public void createDepartment(Department dept) {
		 
		Session session = this.sessionFactory.getCurrentSession();
		session.persist(dept);
		logger.info("Department saved successfully, Department Details="
		+  dept);
		
	}

	@Override
	public void updateDepartment(Department dept) {
	 
		Session session = 
				this.sessionFactory
				.getCurrentSession();
		session.update( dept);
		logger.info("Department updated successfully, "
				+ "Department Details=" +  dept);
		
	}

	@Override
	public void deleteDepartment(int deptidt) {
	 
		Session session = this.sessionFactory.getCurrentSession();
		Department p = 
		( Department) session.load( Department.class, new Integer( deptidt));
		if (null != p) {
			session.delete(p);
		}else {
			logger.error
			("Person NOT deleted, with person Id=" + deptidt);
		}
		logger.info("Person deleted successfully, person details=" + p);
	}

	
	
	@Override
	public Department getDepartment(int id) {
 
		Session session = this.sessionFactory.getCurrentSession();
		Department p = ( Department) session.load( Department.class, new Integer(id));
		logger.info("Person loaded successfully, Person details=" + p);
		return p;
	}

	@Override
	public List<Department> getByName(String name) {
		Session session = this.sessionFactory.getCurrentSession();
//		List<EmployeeDetails> personsList = session.createQuery("from EmployeeDetails").list();
		List< Department> personsList = ( List< Department>) session.load(  Department.class, new String(name));
		logger.info("Person loaded successfully, Person details=" + personsList);
		
		for ( Department p : personsList) {
			logger.info("Person List::" + p);
		}
		return personsList;
		 
	}



	
	
}

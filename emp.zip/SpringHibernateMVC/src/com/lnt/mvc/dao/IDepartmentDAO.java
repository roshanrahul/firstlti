package com.lnt.mvc.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.lnt.mvc.model.Department;
import com.lnt.mvc.model.EmployeeDetails;


@Repository
public interface IDepartmentDAO {
 
		
		public void createDepartment(Department dept);
		
		public void updateDepartment(Department dept);
		
		public void deleteDepartment(int deptidt);
		
		
		public Department getDepartment(int id);
		public List<Department> getByName(String name);
	 
		
 

}

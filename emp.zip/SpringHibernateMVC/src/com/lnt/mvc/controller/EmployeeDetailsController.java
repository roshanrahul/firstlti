package com.lnt.mvc.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.lnt.mvc.exception.CustomException;
import com.lnt.mvc.model.EmployeeDetails;
import com.lnt.mvc.model.Person;
import com.lnt.mvc.service.IEmployeeDetailsService;


@Controller
public class EmployeeDetailsController {
@Autowired
private IEmployeeDetailsService  iEmployeeDetailsService;

 


//@Qualifier(value = " iEmployeeDetailsService")
public void setiEmployeeDetailsService(IEmployeeDetailsService iEmployeeDetailsService) {
	this.iEmployeeDetailsService = iEmployeeDetailsService;
}

 
@RequestMapping(value = "/employee", method = RequestMethod.GET)
public String listPersons(Model model) {
	model.addAttribute("employeeDetails", new EmployeeDetails());// model
	model.addAttribute("listPersons", 
			this. iEmployeeDetailsService.getEmployeeDetails());
	return "employees";// view name
}








@RequestMapping(value = "/employee/add", 
method = RequestMethod.POST)
@ExceptionHandler({ CustomException.class })
public String addEmployee(
@ModelAttribute("employee") 
@Valid EmployeeDetails e, 
BindingResult result, 
Model model) {
if (!result.hasErrors()) 
if (e.getEmployee_id() == null) {
	// new person, add it
	this.iEmployeeDetailsService.createEmployeeDetails(e);
} else {
 
	this.  iEmployeeDetailsService.updateEmployeeDetails(e);
}
return "redirect:/p";
}


}
